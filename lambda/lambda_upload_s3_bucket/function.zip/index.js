import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
const parser = require('lambda-multipart-parser');
const s3 = new S3Client();


export const handler = async (event) => {
  try {
    const result = await parser.parse(event);

    // Assume only one file is uploaded; adjust if multiple
    const file = result.files[0];
    if (!file) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "No file uploaded" }),
      };
    }

    // Prepare S3 upload parameters
    const params = {
      Bucket: process.env.S3_BUCKET_NAME, // Set your bucket name in environment variables
      Key: file.filename,
      Body: file.content,
      ContentType: file.contentType,
    };

    const command = new PutObjectCommand(params);

    // Upload to S3
    await s3.send(putObjCmd);
    
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" }, // Enable CORS if needed
      body: JSON.stringify({
        message: "File uploaded successfully",
        fileUrl: uploadResult.Location,
      }),
    };
  } catch (error) {
    console.error("Upload error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error uploading file" }),
    };
  }
};
